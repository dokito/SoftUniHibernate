package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.math.BigDecimal;
import java.util.List;

@Entity
public abstract class BasicChemicalIngredient extends BasicIngredient implements ChemicalIngredient{

    @Column(name = "chemical_formula")
    String chemicalFormula;

    protected BasicChemicalIngredient() {
    }

    public BasicChemicalIngredient(String name, BigDecimal price, String chemicalFormula) {
        super(name, price);
        this.chemicalFormula = chemicalFormula;
    }

    @Override
    public void setShampoos(List<BasicShampoo> shampoos) {

    }

    @Override
    public void setChemicalFormula(String chemicalFormula) {

    }

    @Override
    public String getChemicalFormula() {
        return null;
    }
}
