package entities;

public interface ChemicalIngredient extends Ingredient {
    void setChemicalFormula(String chemicalFormula);
    String getChemicalFormula();
}
