package entities;

public class ChemicalIngredients {
    private String chemicalFormula;
}
