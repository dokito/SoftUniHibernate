package entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import java.math.BigDecimal;
import java.util.List;

@Entity
@DiscriminatorValue(value = "MN")
public class Mint extends BasicIngredient {

    private static final String NAME = "Mint";
    private static final BigDecimal PRICE = new BigDecimal("3.54");

    public Mint() {
        super(NAME, PRICE);
    }

    @Override
    public String getName() {
        return this.getName();
    }

    @Override
    public void setName(String name) {
        this.setName(name);
    }

    @Override
    public int getId() {
        return this.getId();
    }

    @Override
    public void setId(int id) {
        this.setId(id);
    }

    @Override
    public BigDecimal getPrice() {
        return this.getPrice();
    }

    @Override
    public void setPrice(BigDecimal price) {
        this.setPrice(price);
    }

    @Override
    public List<BasicShampoo> getShampoos() {
        return this.getShampoos();
    }

    @Override
    public void setShampoos(List<BasicShampoo> shampoos) {
        this.setShampoos(shampoos);
    }
}
