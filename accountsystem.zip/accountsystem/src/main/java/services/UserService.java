package services;

import models.User;

public interface UserService {
    void registerUser(User user);
}
