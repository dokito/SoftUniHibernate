package repositories;

import javax.persistence.Id;
import java.util.List;

public interface CrudRepository<E, Long> {

    void save(E entity);

    E findOne(Id primaryKey);

    List<E> findAll();

    int count();

    void delete(E entity);

    boolean exists(Id primaryKey);
}
