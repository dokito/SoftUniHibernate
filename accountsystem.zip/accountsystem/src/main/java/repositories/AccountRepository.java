package repositories;

import models.Account;

public interface AccountRepository extends CrudRepository<Account, Long> {

}
