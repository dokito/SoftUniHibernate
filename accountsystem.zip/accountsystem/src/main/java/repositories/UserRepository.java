package repositories;

import models.User;

import javax.persistence.Id;
import java.util.List;

public interface UserRepository extends CrudRepository<User, Long> {


}
