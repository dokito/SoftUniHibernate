package models;


import org.hibernate.annotations.Check;
import org.hibernate.annotations.Generated;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import java.math.BigDecimal;

import static javax.persistence.GenerationType.IDENTITY;

public class Account {
//
//    Id – long value, primary key
//
//    Balance – BigDecimal, cannot be negative
//
//    User – an account can be owned by a single user

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id")
    private long id;

    @Column(name = "balance")
    @Check(constraints = "balance >= 0")
    private BigDecimal balance;

    @Column(name = "users")
    private User user;

    public Account() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
